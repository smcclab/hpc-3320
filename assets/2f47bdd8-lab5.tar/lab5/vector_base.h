/* 
 * File:   vector_base.h
 * Author: Jiri Jaros
 *
 * Created on 14 May 2012, 12:08 PM
 */

#ifndef VECTOR_BASE_H
#define	VECTOR_BASE_H



void AllocateMemory(float ** array, const size_t size);

void FreeMemory(float * array);

void FillArray(float * array, const size_t size);

void PrintVector(float * array, const size_t size, const char * name);




#endif	/* VECTOR_BASE_H */

