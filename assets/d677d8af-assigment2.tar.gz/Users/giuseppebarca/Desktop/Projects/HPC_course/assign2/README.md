This code uses a CMake build system.
In order to build the code you will need to have CMake version >= 3.12 installed.
If CMake is not installed on your system, please follow the installation instructions
   on the CMake website https://cmake.org/install/

IMPORTANT NOTE: you will not be able to use the code in visualization mode on Gadi. 
                Gadi supports only the kernel mode execution of this code.
                You will be able to use the visualization mode on your machine 
                if you have OpenGL and GLUT installed.  

In order to build the code on your machine execute the following code from
    within your assign2 directory:
    1 mkdir build 
    2 cd build
    3 cmake ..
    4 make

Now the executable of your code named "cloth" will be in the build directory.

IF YOU ARE ON GADI: please use the intel compiler. In order to do so, BEFORE 
    executing the above-repored build instructions, please load the intel 
    compiler module and the cmake module by executing
    
    module load intel-compiler
    module load cmake

BUILDING THE CODE IN KERNEL MODE: in order to build the code in kernel mode
    you need to edit the file "CMakeListz.txt". More specifically you will need
    to uncomment line 47 and comment out line 49. 
