#include <stdio.h>
#include <omp.h>

int main(void){
  int i=1,j=2;

  printf(" Initial value of i %i and j %i \n",i,j);

  #pragma omp parallel default(shared) private(i)
  {  
     printf(" Parallel value of i %i and j %i \n",i,j);
     i=i+1;
  }

  printf(" Final value of i %i and j %i \n",i,j);
  return 0;
}
