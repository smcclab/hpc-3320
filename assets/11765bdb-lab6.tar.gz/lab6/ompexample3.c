#include <stdio.h>
#include <stdlib.h>
#include <omp.h>

int main(int argc, char* argv[]){
   int np, iam, nthread, mxthread;


  if (argc != 2) {
    printf(" %s Number_of_threads \n",argv[0]);
    return -1;
  }
    else {
      np = atoi(argv[1]);
      if (np < 1){
        printf("Error: Number_of_threads (%i) < 1 \n",np);
        return -1;
      }
  }

   omp_set_num_threads(np);

   nthread=omp_get_num_threads();
   mxthread=omp_get_max_threads();
   printf("Before Parallel: nthread=%i mxthread %i\n",nthread,mxthread);
#pragma omp parallel default(none) private(nthread,iam)
   {
   nthread=omp_get_num_threads();
   iam=omp_get_thread_num();
   printf("In Parallel: nthread=%i iam=%i \n",nthread,iam);
   }
   nthread=omp_get_num_threads();
   printf("After Parallel: nthread=%i \n",nthread);

   return 0;
}
